<template>
  <div class="contact">
      <contact/>
  </div>
</template>

<script>

import Contact from '../components/Features/Contact'
export default {
    components: {
        Contact,
    }

}
</script>

<style>

.contact {
    padding: 50px 0;
}

</style>